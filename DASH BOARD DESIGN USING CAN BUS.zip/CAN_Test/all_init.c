#include "myheader.h"

u8 s[]=" WELCOME TO ",str[]="VECTOR INDIA ";
u8 p[]="DASH BOARD DESIGN",q[]="USING CAN BUS";
const u8 Cgram[]={0X10,0X18,0X1C,0X1F,0X1E,0X1C,0X18,0X10,  // RIGHT INDICATOR [0]
				  0X01,0X03,0X07,0X1F,0X0F,0X07,0X03,0X01,  // LEFT INDICATOR  [1]
				  0X0E,0X1B,0X11,0X11,0X11,0X11,0X11,0X1F,  // 0%			   [2]
				  0X0E,0X1B,0X11,0X11,0X11,0X1F,0X1F,0X1F,  // 25%			   [3]
				  0X0E,0X1B,0X11,0X11,0X1F,0X1F,0X1F,0X1F, //  50%			   [4]
				  0X0E,0X1B,0X11,0X1F,0X1F,0X1F,0X1F,0X1F, //  75%			   [5]
				  0X0E,0X1F,0X1F,0X1F,0X1F,0X1F,0X1F,0X1F}; // 100%            [6]

s32 temp;u8 tp,tpd;u32 h,m,sec,da,mn,year,day;
struct CAN_Frame txFrame,rxFrame;
extern u8 i_flag,i_flag1;

void Display_pro_name(u8 *s1,u8 *s2)
{
	u8 i;
	for(i=0;s1[i];i++)
	{
		Cmd_LCD(GOTO_LINE2_POS0+2+i);
		Char_LCD(s1[i]);
		if(s2[i]!='\0')
		{
			Cmd_LCD(GOTO_LINE3_POS0+4+i);
			Char_LCD(s2[i]);
		}
		delay_ms(100);
	}
}

void all_init(void)
{
	Init_CAN1();
	Init_LCD();
	Enable_EINT0();
	Enable_EINT1();
	RTC_Init();
	print_border();
	animation_lcd(s,str);
	delay_ms(3000);
	Cmd_LCD(GOTO_LINE2_POS0+1);
	Str_LCD("                  ");
	Cmd_LCD(GOTO_LINE3_POS0+1);
	Str_LCD("                  ");
	//print_border();
	Display_pro_name(p,q);
	delay_ms(2000);
	Cmd_LCD(CLRLCD);
	BuildCGRAM_LCD(Cgram,56);
	txFrame.vbf.RTR=0;
	txFrame.vbf.DLC=1;
	RTCSetTime(11,30,0);
	RTCSetDate(1,9,2025);
	RTCSetDay(1);
}

void Fuel(void)
{
	SetCursor(3,7);
	Str_LCD("       ");
	if(rxFrame.Data1==0)
	{
		SetCursor(3,7);
		Char_LCD(2);
	}
	else if((rxFrame.Data1>0)&&(rxFrame.Data1<=25))
	{
		SetCursor(3,7);
		Char_LCD(3);
	}
	else if((rxFrame.Data1>25)&&(rxFrame.Data1<=50))
	{
		SetCursor(3,7);
		Char_LCD(4);
	}
	else if((rxFrame.Data1>50)&&(rxFrame.Data1<=75))
	{
		SetCursor(3,7);
		Char_LCD(5);
	}
	else if((rxFrame.Data1>75)&&(rxFrame.Data1<=100))
	{
		SetCursor(3,7);
		Char_LCD(6);
	}
	if(rxFrame.Data1>99)
	{
		SetCursor(3,15);
		Str_LCD("     ");
	}
	if(rxFrame.Data1<100)
	{
		SetCursor(3,15);
		Str_LCD("     ");
	}
	SetCursor(3,15);
	U32_LCD(rxFrame.Data1);
	Char_LCD('%');
}

void Display_RTC_DS18B20(void)
{
	if((C1GSR&RBS_BIT_READ))
	{
		CAN1_Rx(&rxFrame);
	} 
	RTCGetTime(&h,&m,&sec);
	RTCGetDate(&da,&mn,&year);
	RTCGetDay(&day);
	temp=ReadTemp();
	tp=temp>>4;
	tpd=temp&0x08?0x35:0x30;
	DisplayRTCTime(h,m,sec);
	DisplayRTCDate(da,mn,year);
	DisplayRTCDay(day);
	SetCursor(2,0);
	Str_LCD("Temp: ");
	U32_LCD(tp);
	Char_LCD('.');
	Char_LCD(tpd);
	Char_LCD(223);
	Char_LCD('C');
	SetCursor(3,0);
	Str_LCD("Fuel: ");
	if(rxFrame.ID==2)
	{
		Fuel();
	}
	else
	{
		SetCursor(3,7);
		Str_LCD("NODE NC");
	}
	SetCursor(4,0);
	Str_LCD("Indicator: ");
	if((i_flag==0)&&(i_flag1==0))
	{
		SetCursor(4,11);
		Char_LCD(1);
		SetCursor(4,12);
		Char_LCD(0);
		SetCursor(4,15);
		Str_LCD("OFF  ");
	}
	if((i_flag==1)||(i_flag1==1))
	{
		/*if((C1GSR&RBS_BIT_READ))
		{
			CAN1_Rx(&rxFrame);
		} */
		//if(rxFrame.ID==3)
		//{
			//if(rxFrame.vbf.RTR==0)
			//{
				CAN1_Tx(txFrame);
				if((i_flag==1)&&(i_flag1==0))
				{
					SetCursor(4,12);
					Char_LCD(' ');
					delay_ms(100);
					SetCursor(4,12);
					Char_LCD(0);
					delay_ms(50);
					SetCursor(4,15);
					Str_LCD("RIGHT");
				}
				else if(i_flag1==1)
				{
					SetCursor(4,11);
					Char_LCD(' ');
					delay_ms(100);
					SetCursor(4,11);
					Char_LCD(1);
					delay_ms(50);
					SetCursor(4,15);
					Str_LCD("LEFT ");
				}
			//}
		}
		//else
		//	i_flag=i_flag1=0;
	//}
	else if((i_flag==2)||(i_flag1==2))
	{
			CAN1_Tx(txFrame);
			i_flag=0,i_flag1=0;
	}
		else
			i_flag=0,i_flag1=0;
}
