#ifndef __ALL_INIT_H__
#define __ALL_INIT_H__

void Display_pro_name(u8 *,u8 *);
void all_init(void);
void Display_RTC_DS18B20(void);

#endif
