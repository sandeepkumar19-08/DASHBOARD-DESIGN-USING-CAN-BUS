              /*defines.h */
#ifndef _DEFINES_H_
#define _DEFINES_H_

#define SETBIT(W,BP) (W|=(1<<BP))

#define CLRBIT(W,BP) (W&=~(1<<BP))

#define CPLBIT(W,BP) (W^=(1<<BP))

#define WRBIT(W,SBP,BIT) W=((W&~(1<<SBP))|(BIT<<SBP))

#define RDBIT(W,BP) ((W>>BP)&1)

#define WRN(W,SP,N) W=((W&~(15<<SP))|((N&15)<<SP))

#define RDN(W,SBP) ((W>>SBP)&15)

#define WRBYTE(W,SBP,BYTE) W=((W&~(255<<SBP))|(BYTE<<SBP))

#define RDBYTE(W,SBP) ((W>>SBP)&255)

#define SSETBIT(W,BP) W=1<<BP

#define SCLRBIT SSETBIT    

#endif
