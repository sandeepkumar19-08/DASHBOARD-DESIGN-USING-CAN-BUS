           /* delay.c */
#include "myheader.h"

void delay_us(u32 dlyUS)
{
	dlyUS*=12;//@CPU clock 60MHz
	while(dlyUS--);
}	

void delay_ms(u32 dlyMS)
{
	dlyMS*=12000;//@CPU clock 60MHz
	while(dlyMS--);
}	

void delay_s(u32 dlyS)
{
	dlyS*=12000000;//@CPU clock 60MHz
	while(dlyS--);
}	
