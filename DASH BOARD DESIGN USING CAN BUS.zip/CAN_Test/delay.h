          /* delay.h */
#ifndef _DELAY_H_
#define _DELAY_H_

#include "myheader.h"

void delay_us(u32 dlyUS);
void delay_ms(u32 dlyMS);
void delay_s(u32 dlyS);

#endif
