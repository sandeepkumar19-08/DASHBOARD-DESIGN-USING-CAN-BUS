#ifndef _EINT0_H_
#define _EINT0_H_

void eint0_isr(void) __irq;
void Enable_EINT0(void);
void eint1_isr(void) __irq;
void Enable_EINT1(void);

#endif
