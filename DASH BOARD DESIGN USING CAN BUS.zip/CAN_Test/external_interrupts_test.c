                 /* external_interrupt_test.c */
#include "myheader.h"

u8 i_flag,i_flag1;
extern struct CAN_Frame txFrame;
void Enable_EINT0(void)
{
	CFGPIN(PINSEL0,1,FUNC4);
	SSETBIT(VICIntEnable,14);
	VICVectCntl0=0x20|14;
	VICVectAddr0=(unsigned)eint0_isr;
	//EINT0 as EDGE_TRIG
	SSETBIT(EXTMODE,0);
}	

void eint0_isr(void) __irq
{
	if(i_flag==1)
	{
		i_flag=2;
		txFrame.Data1='O';
	}
	else
	{
		i_flag=1;
		i_flag1=0;
		txFrame.Data1='L';
	}
	delay_ms(200);
	txFrame.ID=1;
	//txFrame.Data1='L';
	EXTINT=1<<0;
	VICVectAddr=0;//dummy write;
}	

void Enable_EINT1(void)
{
	CFGPIN(PINSEL0,3,FUNC4);
	SSETBIT(VICIntEnable,15);
	VICVectCntl1=0x20|15;
	VICVectAddr1=(unsigned)eint1_isr;
	SSETBIT(EXTMODE,1);
}	

void eint1_isr(void) __irq
{
	if(i_flag1==1)
	{
		i_flag1=2;
		txFrame.Data1='O';
	}
	else
	{
		i_flag1=1;
		i_flag=0;
		txFrame.Data1='R';
	}
	delay_ms(200);
	txFrame.ID=1;
	//txFrame.Data1='R';
	EXTINT=1<<1;
	VICVectAddr=0;//dummy write;
}
