#include "myheader.h"

#define Min	0.32
#define Max 1.95

f32 eAR;
u32 f_per;

struct CAN_Frame txFrame;

int main()
{
	Init_CAN1();
	Init_ADC();
	txFrame.vbf.RTR=0;
	txFrame.vbf.DLC=1;
	txFrame.ID=2;
	while(1)
	{
		eAR=Read_ADC(0);
		f_per=((eAR-Min)/(Max-Min))*100;
		if(f_per>100)
			f_per=100;
		txFrame.Data1=f_per;
		CAN1_Tx(txFrame);
		//delay_ms(1000);
	}
}

/*int main()
{
	Init_ADC();
	Init_LCD();
	while(1)
	{
		Cmd_LCD(0x80);
		eAR=Read_ADC(0);
		F32_LCD(eAR,2);
	}
} */
