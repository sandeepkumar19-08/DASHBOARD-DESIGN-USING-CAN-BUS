#include "myheader.h"

#define Min	0.45
#define Max 2.91

f32 eAR;
u32 f_per;

int main()
{
	Init_ADC();
	Init_LCD();
	while(1)
	{
		eAR=Read_ADC(0);
		SetCursor(1,0);
		Str_LCD("Fuel: ");
		F32_LCD(eAR,2);
		f_per=((eAR-Min)/(Max-Min))*100;
		SetCursor(2,0);
		Str_LCD("F_per: ");
		U32_LCD(f_per);
		delay_ms(1000);
	}
}
