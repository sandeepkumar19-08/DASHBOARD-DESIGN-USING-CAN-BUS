//#include "pro_header.h"

//extern char r_flag;
#include "myheader.h"
#define USE 0

void Write_LCD(u8 data)
{
	//SCLRBIT(IOCLR0,LCD_RW);
	WRN(IOPIN0,LCD_DATA,(data>>4));
	SSETBIT(IOSET0,LCD_EN);
	delay_us(1);
	SCLRBIT(IOCLR0,LCD_EN);
	//delay_ms(2);
	WRN(IOPIN0,LCD_DATA,(data&15));
	SSETBIT(IOSET0,LCD_EN);
	delay_us(1);
	SCLRBIT(IOCLR0,LCD_EN);
	delay_ms(2);
}

void Cmd_LCD(u8 cmd)
{
	SCLRBIT(IOCLR0,LCD_RS);
	Write_LCD(cmd);
}

void Char_LCD(u8 Sdata)
{
	SSETBIT(IOSET0,LCD_RS);
	Write_LCD(Sdata);
}

void Init_LCD(void)
{
	WRN(IODIR0,LCD_DATA,15);
	SETBIT(IODIR0,LCD_RS);
	//SETBIT(IODIR0,LCD_RW);
	SETBIT(IODIR0,LCD_EN);
	delay_ms(15);
	Cmd_LCD(0x20);
	delay_ms(4);
	Cmd_LCD(0x20);
	delay_us(100);
	Cmd_LCD(0x20);
	Cmd_LCD(RET_CUR_HOME);
	Cmd_LCD(MODE_4BIT_2LINE);
	Cmd_LCD(DISP_ON_CUR_OFF);
	Cmd_LCD(CLRLCD);
	Cmd_LCD(SHIFT_DISP_RIGHT);
	//Cmd_LCD(CLRLCD);
}

void SetCursor(u8 lineno,u8 pos)
{
	if(lineno==1)
	{
		Cmd_LCD(GOTO_LINE1_POS0+pos);
	}
	else if(lineno==2)
	{
		Cmd_LCD(GOTO_LINE2_POS0+pos);		
	}
	else if(lineno==3)
	{
		Cmd_LCD(GOTO_LINE3_POS0+pos);		
	}
	else if(lineno==4)
	{
		Cmd_LCD(GOTO_LINE4_POS0+pos);		
	}
}


void Str_LCD(u8 *p)
{
	while(*p)
	Char_LCD(*p++);
}

void U32_LCD(u32 n)
{
	u8 a[10];
	s32 i=0;
	if(n==0)
	{
		Char_LCD('0');
	}
	else
	{
		while(n)
		{
			a[i++]=n%10+48;
			n=n/10;
		}
		for(--i;i>=0;i--)
		{
			Char_LCD(a[i]);
		}
	}
}
#if USE>0

void S32_LCD(s32 num)
{
	if(num<0)
	{
		Char_LCD('-');
		num=-num;
	}
	U32_LCD(num);
}
#endif

void F32_LCD(f32 f,u32 ndp)
{
	s32 i,t;
	if(f<0.0)
	{
		f=-f;
		Char_LCD('-');
	}
	t=f;
	U32_LCD(t);
	Char_LCD('.');
	for(i=0;i<ndp;i++)
	{
		f=(f-t)*10;
		t=f;
		Char_LCD(t+48);
	}
}

#if USE>0

void Bin_LCD(u8 n,u32 nbd)
{
	s32 i;
	for(i=(nbd-1);i>=0;i--)
	{
		Char_LCD(((n>>i)&1)+48);
	}
}

void Hex_LCD(u32 hex)
{
	 s32 i=0;
        u8 a[8];
        u32 t;
        if(hex==0)
        {
                Str_LCD("0000000");
        }				  
        else
        {
                while(hex)
                {
                        t=(hex%16);
                        t=(t>9)?((t-10)+'A'):(t+48);
                        a[i++]=t;
                        hex/=16;
                }
				Str_LCD("0x");
                for(--i;i>=0;i--)
                        Char_LCD(a[i]);
		}
}

void Octa_LCD(u32 oct)
{	
	u32 t=0;
	u8 a[8];
	s32 i=0;
	if(oct==0)
	{
		 Str_LCD("000");
	}
	else
	{
		while(oct)
		{
			t=oct%8+48;
			a[i++]=t;
			oct/=8;
		}
		Str_LCD("OCTA: ");
        for(--i;i>=0;i--)
        Char_LCD(a[i]);
	}
}
#endif

void BuildCGRAM_LCD(const u8 *p,u32 nbytes)
{
        u32 i;
        //point to CGRAm
        Cmd_LCD(GOTO_CGRAM_START);
        for(i=0;i<nbytes;i++)
        {
                //write to cgram area via data reg
                Char_LCD(p[i]);
        }
        //Cmd_LCD(GOTO_LINE1_POS0);
		//Cmd_LCD(0x80);
		SetCursor(1,0);
}

void print_border(void)
{
	u8 j;
	for(j=0;j<20;j++)
	{
		//Cmd_LCD(GOTO_LINE1_POS0+j);
		SetCursor(1,j);
		Char_LCD('*');
		delay_ms(100);
	}
	//Cmd_LCD(GOTO_LINE2_POS0+19);
	SetCursor(2,19);
	Char_LCD('*');
	delay_ms(100);

	//Cmd_LCD(GOTO_LINE3_POS0+19);
	SetCursor(3,19);
	Char_LCD('*');
	delay_ms(100);

	for(j=0;j<20;j++)
	{
		//Cmd_LCD(GOTO_LINE4_POS0+(19-j));
		SetCursor(4,19-j);
		Char_LCD('*');
		delay_ms(100);
	}

	//Cmd_LCD(GOTO_LINE3_POS0);
	SetCursor(3,0);
	Char_LCD('*');
	delay_ms(100);

	//Cmd_LCD(GOTO_LINE2_POS0);
	SetCursor(2,0);
	Char_LCD('*');
	delay_ms(100);
}

void animation_lcd(u8 *s1,u8 *s2)
{
	u8 i;
	for(i=0;s2[i];i++)
	{
		//Cmd_LCD(GOTO_LINE2_POS0+5+i);
		//Char_LCD(s1[i]);
		//Cmd_LCD(GOTO_LINE3_POS0+4+i);
		SetCursor(3,4+i);
		Char_LCD(s2[i]);
		if(s1[i]!='\0')
		{
			//Cmd_LCD(GOTO_LINE2_POS0+5+i);
			SetCursor(2,4+i);
			Char_LCD(s1[i]);
			//Cmd_LCD(GOTO_LINE3_POS0+4+i);
			//Char_LCD(s2[i]);
		}
		delay_ms(100);
	}
}

/*main()
{
	u8 s[]="WELCOME TO",str[]="VECTOR  ";
	Init_LCD();
	print_border();
	animation_lcd(s,str);
	//Char_LCD('A');
	//Str_LCD("VECTOR");
	while(1);
} */

/*
u8 s2[]="VECTOR",s3[]="HYDERABAD",s4[]="S.R NAGAR LAB",s[100];																																																																																																																																																																																																																																																																																																																																		
//u8 s2[]="SORRY SIR",s3[]="FOR THIS DELAY",s4[]="FROM U R KIDS",s[100];
s32 m=0,j=0,k,l;

void c_scroll(s8 *s1)
{
		Cmd_LCD(0xc0);
		Str_LCD(s2);
		Cmd_LCD(0x94);
		Str_LCD(s3);
		Cmd_LCD(0xd4);
		Str_LCD(s4);
		k=19; 
		j=0;
		while(1)
		{
			Cmd_LCD(0x80+k);
			s[j]=s1[j];
			if(r_flag==1)
			{
				break;
			}
			if(k==19)
			{
			Char_LCD(s[j]);
			j++;
			k--;
			}
			else
			{
			delay_ms(100);
			Str_LCD(s);
			if(k==0)
			{
				for(m=0;m<strlen((const char *)s);m++)
				{
					if(r_flag==1)
					{
						break;
					}
					s[j]=s1[j];
					Cmd_LCD(0x80);
					Str_LCD(s+m);
					delay_ms(100);
					j++;
				}
				 break;
			} 
			j++;
			k--;
			}
		}
		memset(s,'\0',100);
}
  */
