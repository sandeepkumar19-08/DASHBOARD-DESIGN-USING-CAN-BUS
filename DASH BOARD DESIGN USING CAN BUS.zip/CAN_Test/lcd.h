#ifndef __LCD_H__
#define __LCD_H__

void Init_LCD(void);
void Char_LCD(u8);
void Write_LCD(u8);
void Cmd_LCD(u8);
void U32_LCD(u32);
void S32_LCD(s32);
void F32_LCD(f32,u32);
void Bin_LCD(u8,u32);
void Hex_LCD(u32);
void BuildCGRAM_LCD(const u8 *,u32);
void SetCursor(u8,u8);
void Str_LCD(u8 *);
void Octa_LCD(u32);
void c_scroll(s8 *s1);
void print_border(void);
void animation_lcd(u8 *,u8 *);

#endif
