#include "myheader.h"

#define INTERVAL 3
#define AL_LED 0

struct CAN_Frame rxFrame,txFrame;
  
main()   
{
	s32 i,start;      
  	Init_CAN1();
	WRBYTE(IODIR0,AL_LED,255);
	WRBYTE(IOPIN0,AL_LED,255);
	while(1)   
	{  
		/*if((C1GSR&RBS_BIT_READ))
		{ 
			txFrame.ID=3;
			txFrame.vbf.RTR=0;
			CAN1_Tx(txFrame);
        	CAN1_Rx(&rxFrame);
		} */
	/*	else
		{
			txFrame.ID=3;
			txFrame.vbf.RTR=1;
			CAN1_Tx(txFrame);
		}*/
		CAN1_Rx(&rxFrame);
		if((rxFrame.ID==1)&&(rxFrame.Data1=='L'))
		{
			for(i=0;i<8;i++)
			{
				start=0;
				CAN1_Rx(&rxFrame);
				if(rxFrame.Data1=='R')
				{
					break;
				}
				while(start<INTERVAL)
				{
					IOPIN0=(1<<i)^0XFF;
					CAN1_Rx(&rxFrame);
					if(rxFrame.Data1=='R')
					{
						break;
					}
					start++;
					if(rxFrame.Data1=='O')
					{
						IOPIN0=0XFF<<AL_LED;
						break;
					}
				}
				if(rxFrame.Data1=='O')
				{
					IOPIN0=0XFF<<AL_LED;
					break;
				}
			}
		}
		else if((rxFrame.ID==1)&&(rxFrame.Data1=='R'))
		{
			for(i=7;i>=0;i--)
			{
				start=0;
				CAN1_Rx(&rxFrame);
				if(rxFrame.Data1=='L')
				{
					break;
				}
				if(rxFrame.Data1=='O')
				{
					IOPIN0=0XFF<<AL_LED;
					break;
				}
				while(start<INTERVAL)
				{
					IOPIN0=(1<<i)^0XFF;
					CAN1_Rx(&rxFrame);
					if(rxFrame.Data1=='L')
					{
						break;
					}
					start++;
					if(rxFrame.Data1=='O')
					{
						IOPIN0=0XFF<<AL_LED;
						break;
					}
				}
			}
		}
		if(rxFrame.Data1=='O')
		{
			IOPIN0=0XFF<<AL_LED;
		}    
	}    
}
