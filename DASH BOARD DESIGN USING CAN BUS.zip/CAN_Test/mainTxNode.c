#include "myheader.h"

//struct CAN_Frame txFrame;
extern u8 i_flag,i_flag1;

int main()    
{    
	all_init();    											  
	i_flag=i_flag1=0;
	while(1)    
  	{
		//do
		//{	
			Display_RTC_DS18B20();
			//delay_ms(1000);
		//}while((i_flag==0)&&(i_flag1==0));
		/*if((i_flag==2)||(i_flag1==2))
		{
			CAN1_Tx(txFrame);
			i_flag=0,i_flag1=0;
		}
		else
		{
			CAN1_Tx(txFrame);
		} */
  	}    
}

