#ifndef _MYHEADER_H_
#define _MYHEADER_H_

#include<lpc21xx.h>
#include "types.h"
#include "defines.h"
#include "delay.h"
#include "can.h"
#include "can_defines.h"
#include "pin_function_defines.h"
#include "eint0.h"
#include "lcd.h"
#include "lcd_defines.h"
#include "ds18b20.h"
#include "rtc.h"
#include "rtc_defines.h"
#include "all_init.h"
#include "adc_defines.h"
#include "adc.h"

#endif
