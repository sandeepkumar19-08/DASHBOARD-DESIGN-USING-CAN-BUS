#ifndef __RTC_H__
#define __RTC_H__

void RTC_Init(void);
void RTCGetTime(u32 *,u32 *,u32 *);
void DisplayRTCTime(u32,u32,u32);
void RTCGetDate(u32 *,u32 *,u32 *);
void DisplayRTCDate(u32,u32,u32);
void RTCGetDay(u32 *);
void DisplayRTCDay(u32);
void RTCSetTime(u32,u32,u32);
void RTCSetDate(u32,u32,u32);
void RTCSetDay(u32);
void display_RTC(void);
void check_status(void);
void display_on_off_time(u8,u8);
void display_info(void);
void display_box(void);


#endif
